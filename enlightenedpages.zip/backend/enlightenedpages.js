export const serviceAccount = {
  type: "service_account",
  project_id: "enlightenedpages-53b05",
  private_key_id: "6adcca77c42415624e31efd41383bf48bc3d09fd",
  private_key:
    "-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCWsp0+ywRPEV45\nUDdabvIDSt59MVX9UcWkdqwOcfju5oSMeEbCOW3OtXbD+xjt+hAYm1qonD01hXse\n60seYBuxDGYzmlaiDL1BI5vr5KpwKi9yV0rrDkZ/UJM5Y6UPYVJWVXjp4SDIIJKZ\nXtyvNIWYLWHzChh/G7f+IWqpN2nFB6/hKdV1TGrdkcrP2c0P4XN/gWc+wCMyX0J6\nPtPUfpj3j8ZrSuDQYwjdVQE3SlbwciyGCkIKb5mQwPSreweOQLthW5vl/Y64Z270\nnhTckKDcomCH/8vfXqYzLLeHcMAC3khvdWjtDi7UZz6y4xSWIFN6Fl2llDeDJApl\nYkSZ2rvRAgMBAAECggEACTT4bnGw3bPN8ep4t0m394OHfFabTlLEpHurn2ZPMyla\nR8rBZ/RiRRLJIsggicmRWi+DpnGFO9Pf5c+yUzTD/FkplVWEnXnxxh0K1aquzxOE\nupOivCGvJPAjTopL91iW0zd9n6xleFSlIEGvcfTfhKChL1waiwmCgEBCZ/w+tg7e\nJwx+SmJYuvo9X73xUFOgDtZLlPbJm2Rtr3MImTDaWzxuih2Wmv+QYeg9HoRXOE6x\nqYtVwV2i3+18cOVj/9hkMfGCOzYYsBgina0h2zylU/7Ld5ChcTyG49JXLGI1mI38\ncE2Pomr0De1OQrMbIBIqmrZuJoyPPfgYxPyP+VXZUQKBgQDMYozOQGJegWi5pYJ4\n4G0T2Wq2w3Tw7Co2u/kTO7CBa9P40zZjg4wSyB5iwwLxsmuPVb/wnugCLqSRf7SZ\nbnImkzXzS/W4NaN5Qu9/cXJoauJhLrUi8QsKtyEsijxDjAMuxxlHFsj3EFEulMZU\nWTez3jdzPBWMMRUrDCU5Wrkf2wKBgQC8wTGHqX4uShGEH6TAedDtr2aVKhJBvDsd\nZb0ujXWiJ024NFTkEmQr82pXb9aAT0tIhaUm6/PBeyaX9S86Yof+R0LNYgBtg/3X\nJQnqC9I6cwVWqZbOqWfNlpBWpKENCe9/CrGOBKZ/kuV1pdM8U5Zbx8rplQ3FgCJj\nwT2/77vowwKBgFOdAZOjPVsCQBCqyDyhO56CNKj+P0oMo5xuvBAFPElGDprd9YMy\nnsxUODIZK4wrfNtPrk1HBQ1XfZXUk9KtH1/um4SkD6tDrlP+cTJG/BIBoAk37XyU\n9fp1PsoU52CO2AJ8CzhM9vw0HbIbxSNeuG4KO88Vxo7qyYkp19Sl69Q/AoGAN7Ob\ndjliby6UdLUR3WsVaM72Kta7hIKTv10isvYz3KJUoSNwWc3DmeS/YQYz+rFruf8W\neaHv0Q0Smo1UXpptH3DQGePt1GO7KR5ZCqRqaa0/yg9J3brIUzc3aRo0HLDt6EOz\nmgFtUQB8jnddGtRf7r3K95tw8PObMmz4WAfbIBkCgYEAt2sJXllpQDdW/8PaZbrv\nhi5hAphUN6lh2T6zRCz1+x00roXD0dFQf3io9Gu5DBhQU2w+x/PKNqZNvLP+ATD9\niWXufYkA2PgohF5TtPu4QZmCBFX229/BUMHll4PXEkRqQtMfGAPtkB1UaGXBIeZ3\nB9WqeplBrcVzkC9OQogxUPQ=\n-----END PRIVATE KEY-----\n",
  client_email:
    "firebase-adminsdk-lnsgv@enlightenedpages-53b05.iam.gserviceaccount.com",
  client_id: "106722486354668898723",
  auth_uri: "https://accounts.google.com/o/oauth2/auth",
  token_uri: "https://oauth2.googleapis.com/token",
  auth_provider_x509_cert_url: "https://www.googleapis.com/oauth2/v1/certs",
  client_x509_cert_url:
    "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-lnsgv%40enlightenedpages-53b05.iam.gserviceaccount.com",
  universe_domain: "googleapis.com",
};
