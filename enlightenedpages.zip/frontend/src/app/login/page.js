"use client";
import React, { useEffect } from "react";
import "firebaseui/dist/firebaseui.css";
import { auth, firebaseExp, firebaseUI } from "../firebase.config.js";
import axios from "axios";

const LoginPage = () => {
  useEffect(() => {
    const loadFirebaseUI = async () => {
      const ui =
        firebaseUI.auth.AuthUI.getInstance() ||
        new firebaseUI.auth.AuthUI(auth);

      ui.start("#firebaseui-auth-container", {
        signInOptions: [
          firebaseExp.auth.FacebookAuthProvider.PROVIDER_ID,
          firebaseExp.auth.GoogleAuthProvider.PROVIDER_ID,
          firebaseExp.auth.EmailAuthProvider.PROVIDER_ID,
        ],
        signInFlow: "popup",
        credentialHelper: firebaseUI.auth.CredentialHelper.NONE,
        callbacks: {
          signInSuccessWithAuthResult: async (currentUser) => {
            if (currentUser) {
              const token = await currentUser.user.getIdToken();

              axios({
                method: "post",
                url: `${process.env.NEXT_PUBLIC_BACKEND_SERVER_PORT}/users/login`,
                data: {
                  name: currentUser.user.displayName,
                  email: currentUser.user.email,
                  _id: token,
                },
              });
            }
            return false;
          },
        },
      });
    };

    loadFirebaseUI();
  }, []);

  return (
    <div>
      <div id="firebaseui-auth-container"></div>
    </div>
  );
};

export default LoginPage;
